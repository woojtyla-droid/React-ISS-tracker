
import React from 'react';
import ReactDOM from 'react-dom';
import IssTracker from './App';

ReactDOM.render(
  <React.StrictMode>
    <IssTracker />
  </React.StrictMode>,
  document.getElementById('root')
);
