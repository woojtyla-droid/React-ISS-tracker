
import React, { useState, useEffect } from 'react';
function IssTracker() {
  const [coordinates, setCoordinates] = useState({ latitude: 0, longitude: 0 });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://api.open-notify.org/iss-now.json');
        if (response.ok) {
          const data = await response.json();
          const { latitude, longitude } = data.iss_position;
          setCoordinates({ latitude, longitude });
        } else {
          console.error('Error fetching data:', response.status);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    const intervalId = setInterval(fetchData, 1000);

    return () => {
      clearInterval(intervalId);
    };
  }, []);

 
  useEffect(() => {
    updateMarker(coordinates.latitude, coordinates.longitude);
  }, [coordinates]);

  return null; 
}

export default IssTracker;
