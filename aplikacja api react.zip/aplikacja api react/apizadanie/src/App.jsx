// src/App.js
import React, { useState, useEffect } from 'react';

function IssTracker() {
  const [coordinates, setCoordinates] = useState({ latitude: '', longitude: '' });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://api.open-notify.org/iss-now.json');
        if (response.ok) {
          const data = await response.json();
          const { latitude, longitude } = data.iss_position;
          setCoordinates({ latitude, longitude });
        } else {
          console.error('Error fetching data:', response.status);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    const intervalId = setInterval(fetchData, 1000);

    return () => {
      clearInterval(intervalId);
    };
  }, []);

  // Przesyłanie danych do index.html
  useEffect(() => {
    const iframe = document.querySelector('iframe');
    if (iframe) {
      iframe.src = `https://maps.google.com/maps?width=100%25&height=600&hl=en&q=${coordinates.latitude},${coordinates.longitude}+(ISS)&t=&z=2&ie=UTF8&iwloc=B&output=embed`;
    }
  }, [coordinates]);

  return (
    <div>
      <h1>ISS Tracker</h1>
      <p>Latitude: {coordinates.latitude}</p>
      <p>Longitude: {coordinates.longitude}</p>
    </div>
  );
}

export default IssTracker;
